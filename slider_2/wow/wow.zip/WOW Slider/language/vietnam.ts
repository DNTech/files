<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="th" sourcelanguage="en">
<context>
    <name>AboutDlg</name>
    <message>
        <source>Version</source>
        <translation>เวอร์ชั่น</translation>
    </message>
</context>
<context>
    <name>AddUrlDlgClass</name>
    <message>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number of photos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">ยกเลิก</translation>
    </message>
    <message>
        <source>Load full description</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExpGalleryDlg</name>
    <message>
        <source>Unable to open file&quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to open file &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Menu publishing error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExpGalleryDlgClass</name>
    <message>
        <source>Page structure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>page:blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selection color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click inside the page to select where you want your slider to appear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">ลบ</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Publish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">ปิด</translation>
    </message>
</context>
<context>
    <name>FaceBookDlgClass</name>
    <message>
        <source>Please authorize on Facebook</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Authorize</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FacebookFileManager</name>
    <message>
        <source>Can&apos;t open file</source>
        <translation type="unfinished">ไม่สามารถเปิดแฟ้มข้อมูลได้</translation>
    </message>
</context>
<context>
    <name>FlickrPhotoset</name>
    <message>
        <source>API key not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User ID not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid url</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FtpManager</name>
    <message>
        <source>New location</source>
        <translation>ตำแหน่งใหม่</translation>
    </message>
    <message>
        <source>Connection ok</source>
        <translation>การเชื่อมต่อ OK</translation>
    </message>
</context>
<context>
    <name>FtpManagerClass</name>
    <message>
        <source>FTP Location Manager</source>
        <translation>ตัวจัดการตำแหน่งของ FTP</translation>
    </message>
    <message>
        <source>Ftp location</source>
        <translation>ตำแหน่งของ FTP</translation>
    </message>
    <message>
        <source>Location name</source>
        <translation>ชื่อตำแหน่ง</translation>
    </message>
    <message>
        <source>FTP Server</source>
        <translation>FTP เซิร์ฟเวอร์</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>พอร์ท</translation>
    </message>
    <message>
        <source>Passive mode</source>
        <translation>Passive mode</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>ชื่อผู้ใช้</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>รหัสผ่าน</translation>
    </message>
    <message>
        <source>Test FTP location</source>
        <translation>ทดสอบตำแหน่งของ FTP</translation>
    </message>
    <message>
        <source>New location</source>
        <translation>ตำแหน่งใหม่</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>ลบ</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>ปิด</translation>
    </message>
</context>
<context>
    <name>Gallery</name>
    <message>
        <source>Unsupported project version</source>
        <translation>โครงงานที่ไม่ได้สนับสนุน เวอร์ชั่น </translation>
    </message>
</context>
<context>
    <name>GalleryExport</name>
    <message>
        <source>File not found</source>
        <translation>ไม่พบแฟ้มข้อมูล</translation>
    </message>
    <message>
        <source>Error processing file</source>
        <translation>เกิดการผิดพลาดในขณะประมวลผลแฟ้มข้อมูล</translation>
    </message>
    <message>
        <source>Can&apos;t load image</source>
        <translation>ไม่สามารถอ่านแฟ้มข้อมูลรูปภาพได้</translation>
    </message>
    <message>
        <source>%1 at line %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open file</source>
        <translation>ไม่สามารถเปิดแฟ้มข้อมูลได้</translation>
    </message>
</context>
<context>
    <name>LocalFileManager</name>
    <message>
        <source>Can&apos;t create path</source>
        <translation>ไม่สามารถสร้าง path ได้</translation>
    </message>
    <message>
        <source>Error writing to file</source>
        <translation>เกิดการผิดพลาดในขณะเขียนแฟ้มข้อมูล</translation>
    </message>
    <message>
        <source>Can&apos;t create file</source>
        <translation>ไม่สามารถสร้างแฟ้มข้อมูลได้</translation>
    </message>
    <message>
        <source>File not exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error open file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Add description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select one or more images to open</source>
        <translation>เลือกเปิดอย่างน้อยหนึ่งรูปภาพ</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>รูปภาพ </translation>
    </message>
    <message>
        <source>Select folder with images</source>
        <translation>เลือกโฟลเดอร์กับรูปภาพ</translation>
    </message>
    <message>
        <source>Add URL to your picasa album or single image.
For example, http://picasaweb.google.com/VLBexe/Flowers#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not supported URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading image thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add images and videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom size</source>
        <translation type="unfinished">ขนาดกำหนดเอง</translation>
    </message>
    <message>
        <source>Add URL to your flickr photostream, photoset or single photo.
For example, http://www.flickr.com/photos/visuallightbox/ 
or http://www.flickr.com/photos/visuallightbox/tags/butterfly/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add URL to your photobucket album or single image.
For example, http://s1008.photobucket.com/user/visuallightbox/library/Butterfly/
or http://s1008.photobucket.com/user/visuallightbox/media/Butterfly/10.jpg.html</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add URL to your Vimeo video.
For example, http://vimeo.com/98694642</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add URL to your YouTube video.
For example, http://www.youtube.com/watch?v=6xDlDG2SF9Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Slider as...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select file for export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTML pages (*.html *.htm);;All files(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select folder for export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Notice that you&apos;re able to share on Facebook 20 images with thumbnails or 40 images without thumbnails.
Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot create slider.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slider was created but cannot share on FaceBook.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <source>%n items</source>
        <translatorcomment>%n รายการ</translatorcomment>
        <translation>
            <numerusform>%n รายการ</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%1 of %n items selected</source>
        <translation>
            <numerusform>%1 จาก %n รายการที่ถูกเลือก</numerusform>
        </translation>
    </message>
    <message>
        <source>Do you want to save the project?</source>
        <translation>คุณต้องการบันทึกโครงงานนี้หรือไม่?</translation>
    </message>
    <message>
        <source>It is necessary to restart the application that changes have come into force</source>
        <translation>จำเป็นต้องเปิดใช้ระบบงานใหม่อีกครั้งเนื่องจากมีการเปลี่ยนแปลงในระบบ</translation>
    </message>
    <message numerus="yes">
        <source>%n bytes</source>
        <translation>
            <numerusform>%n bytes</numerusform>
        </translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>GB</source>
        <translation>GB</translation>
    </message>
</context>
<context>
    <name>MainWindowClass</name>
    <message>
        <source>Title:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Url:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation>ช่วยเหลือ</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>ตัวเลือก</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>ภาษา</translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation>เรียงลำดับโดย</translation>
    </message>
    <message>
        <source>About</source>
        <translation>เกี่ยวกับ</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>ออก</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>เผยแพร่</translation>
    </message>
    <message>
        <source>Delete selected</source>
        <translation>เลือกลบรูปภาพ</translation>
    </message>
    <message>
        <source>Add images...</source>
        <translation>เพิ่มรูปภาพ...</translation>
    </message>
    <message>
        <source>Images &amp;&amp; Videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open recent project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open project...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;Tahoma;Lucida Grande&apos;; font-size:28px; color:#999999;&quot;&gt;1) Drag&amp;amp;drop images or folders with images HERE to get started, or click &lt;/span&gt;&lt;img src=&quot;:/toolbar/add_24.png&quot;/&gt;&lt;span style=&quot; font-family:&apos;Tahoma;Lucida Grande&apos;; font-size:28px; color:#999999;&quot;&gt; &amp;quot;Add images and videos&amp;quot; &lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;Tahoma;Lucida Grande&apos;; font-size:16px; color:#999999;&quot;&gt;2) Choose template and effect &lt;/span&gt;&lt;img src=&quot;:/toolbar/gallery_24.png&quot;/&gt;&lt;span style=&quot; font-family:&apos;Tahoma;Lucida Grande&apos;; font-size:16px; color:#999999;&quot;&gt;, configure options &lt;/span&gt;&lt;img src=&quot;:/toolbar/prop_24.png&quot;/&gt;&lt;span style=&quot; font-family:&apos;Tahoma;Lucida Grande&apos;; font-size:16px; color:#999999;&quot;&gt;&lt;br/&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-family:&apos;Tahoma;Lucida Grande&apos;; font-size:16px; color:#999999;&quot;&gt;3) Publish your slider to your server, local drive, Wordpress or Joomla, insert to html page using &lt;/span&gt;&lt;img src=&quot;:/toolbar/publish_24.png&quot;/&gt;&lt;span style=&quot; font-family:&apos;Tahoma;Lucida Grande&apos;; font-size:16px; color:#999999;&quot;&gt; &amp;quot;Publish&amp;quot;&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>about:blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Same window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Template</source>
        <translation type="unfinished">แม่แบบ</translation>
    </message>
    <message>
        <source>Transition effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multiple effects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can select several effects and the slider will use them randomly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slide size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Boxed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save project as...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Publish Slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete selected slides</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add images to slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move up</source>
        <translation>ย้ายขึ้น</translation>
    </message>
    <message>
        <source>Move up selected images</source>
        <translation>ย้ายรูปที่เลือกขึ้น </translation>
    </message>
    <message>
        <source>Move down</source>
        <translation>ย้ายลง</translation>
    </message>
    <message>
        <source>Move down selected images</source>
        <translation>ย้ายรูปที่เลือกลง</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>เกี่ยวกับ Qt</translation>
    </message>
    <message>
        <source>Add images from folder...</source>
        <translation>เพิ่มรูปภาพจากโฟลเดอร์...</translation>
    </message>
    <message>
        <source>Rotate right</source>
        <translation>หมุนขวา</translation>
    </message>
    <message>
        <source>Rotate left</source>
        <translation>หมุนซ้าย</translation>
    </message>
    <message>
        <source>Caption</source>
        <translation>หัวข้อ</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>วันที่</translation>
    </message>
    <message>
        <source>File name</source>
        <translation>ชื่อแฟ้มข้อมูล</translation>
    </message>
    <message>
        <source>File size</source>
        <translation>ขนาดแฟ้มข้อมูล</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>น้อยไปมาก</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>มากไปน้อย</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>คุณสมบัติ</translation>
    </message>
    <message>
        <source>Add images from Flickr...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add images from Photobucket...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add images from Picasa...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register</source>
        <translation type="unfinished">ลงทะเบียน</translation>
    </message>
    <message>
        <source>Share</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Share on Facebook</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add video from Youtube </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add video from Vimeo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select template, effect and other design properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save as HTML file and preview in browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upgrade to commercial version</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PhotobucketHosting</name>
    <message>
        <source>Invalid url</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PicasaHosting</name>
    <message>
        <source>Invalid url</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgressDlgClass</name>
    <message>
        <source>Progress</source>
        <translation>ความคืบหน้า</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ยกเลิก</translation>
    </message>
</context>
<context>
    <name>PropDlg</name>
    <message>
        <source>General</source>
        <translation>ทั่วไป</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>เผยแพร่ </translation>
    </message>
    <message>
        <source>JPG - JPG/JPEG Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PNG - Portable Network Graphics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse for folder</source>
        <translation>เรียกดูโฟลเดอร์</translation>
    </message>
    <message>
        <source>Specify valid thumbnail size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select template for images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select watermark image</source>
        <translation> </translation>
    </message>
    <message>
        <source>Select one html page to open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTML (*.html *.htm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select one audio file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio (*.mp3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Images</source>
        <translation> </translation>
    </message>
    <message>
        <source>Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Publish gallery</source>
        <translation>เผยแพร่แกลอรี่</translation>
    </message>
    <message>
        <source>Gallery properties</source>
        <translation>คุณสมบัติแกลอรี่</translation>
    </message>
    <message>
        <source>It is necessary to restart the application that changes have come into force</source>
        <translation>จำเป็นต้องเปิดใช้ระบบงานใหม่อีกครั้งเนื่องจากมีการเปลี่ยนแปลงในระบบ</translation>
    </message>
</context>
<context>
    <name>PropDlgClass</name>
    <message>
        <source>Auto play Slide Show</source>
        <translation>ล่นสไลด์โชว์อัตโนมัติ </translation>
    </message>
    <message>
        <source>Template</source>
        <translation>แม่แบบ</translation>
    </message>
    <message>
        <source>Custom size</source>
        <translation>ขนาดกำหนดเอง</translation>
    </message>
    <message>
        <source>Thumbnail quality</source>
        <translation>คุณภาพรูปย่อ</translation>
    </message>
    <message>
        <source>Template preview</source>
        <translation>ดูตัวอย่างแม่แบบ </translation>
    </message>
    <message>
        <source>Image quality</source>
        <translation>คุณภาพรูปภาพ</translation>
    </message>
    <message>
        <source>Preserve aspect ratio</source>
        <translation>คงที่อัตราส่วน</translation>
    </message>
    <message>
        <source>Stretch small images</source>
        <translation>ยืดขยายภาพเล็ก</translation>
    </message>
    <message>
        <source>Shrink large images</source>
        <translation>ลดขนาดภาพใหญ่</translation>
    </message>
    <message>
        <source>Click to enable this option</source>
        <translation>กดปุ่มเพื่อใช้งานตัวเลือกนี้</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation>ลายน้ำ</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>ข้อความ</translation>
    </message>
    <message>
        <source>Advanced...</source>
        <translation> </translation>
    </message>
    <message>
        <source>Image</source>
        <translation> </translation>
    </message>
    <message>
        <source>Slider title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause on mouseover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show descriptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Prev/Next buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thumbnail preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto play video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause/play button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play audio file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation> </translation>
    </message>
    <message>
        <source>Stop slideshow after one loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove frame and shadow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thumbnails size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thumbnail format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show controls on mouseover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full screen button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swipe support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hex</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slider layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Boxed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>960x360</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>960x300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>830x360</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>640x360</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>320x240</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>480x360</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can select several effects and the slider will use them randomly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transition effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2,0 s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delay between slides</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Effect duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image fill color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Publishing method:</source>
        <translation>วิธีการเผยแพร่:</translation>
    </message>
    <message>
        <source>Publish to folder:</source>
        <translation>เผยแพร่ไปยังโฟลเดอร์:</translation>
    </message>
    <message>
        <source>Write the name of the folder where your slider will be situated on the server. Notice that you should specify this field, otherwise your slider will be uploaded into root folder of your server!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open your HTML page. Click inside the page to select where you want your slider to appear, then click &quot;Insert Before&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To create Joomla! module select folder where you want to save it and click &quot;Publish&quot; button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help and tutorial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Share on FaceBook</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Joomla! module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert to page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation>เรียกดู...</translation>
    </message>
    <message>
        <source>Slider size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open web-page after publishing</source>
        <translation>เปิดดูหน้าเว็บหลังการเผยแพร่</translation>
    </message>
    <message>
        <source>Publish to FTP server</source>
        <translation>เผยแพร่ไปยัง FTP เซิร์ฟเวอร์ </translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation>แก้ไข...</translation>
    </message>
    <message>
        <source>FTP Folder</source>
        <translation>โฟลเดอร์ FTP</translation>
    </message>
    <message>
        <source>On-demand image loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use default page color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use relative paths to image in project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show bullet navigation/Filmstrip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bullet navigation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filmstrip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>? - value will be calculated automatically according to aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>64x?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>?x48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0 - value will be calculated automatically according to aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Random order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Index file name</source>
        <translation>ชื่อแฟ้มข้อมูล Index</translation>
    </message>
    <message>
        <source>Slider ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wordpress Slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To create Wordpress plugin slider select folder where you want save it and click &quot;Publish&quot; button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>เผยแพร่</translation>
    </message>
</context>
<context>
    <name>RegisterDlg</name>
    <message>
        <source>Registering application...</source>
        <translation>กำลังลงทะเบียนระบบงาน...</translation>
    </message>
    <message>
        <source>Invalid key</source>
        <translation>รหัสทะเบียนที่ใช้ไม่ถูกต้อง</translation>
    </message>
</context>
<context>
    <name>RegisterDlgClass</name>
    <message>
        <source>Register</source>
        <translation>ลงทะเบียน</translation>
    </message>
    <message>
        <source>Enter your registration key:</source>
        <translation>กรอกรหัสทะเบียนของคุณ:</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>วาง</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>ปิด</translation>
    </message>
</context>
<context>
    <name>UrlHandler</name>
    <message>
        <source>Invalid url</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connection error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thumb not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <source>Select watermark image</source>
        <translation> </translation>
    </message>
    <message>
        <source>Images</source>
        <translation> </translation>
    </message>
</context>
<context>
    <name>WatermarkDlgClass</name>
    <message>
        <source>Watermark settings</source>
        <translation> </translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation> </translation>
    </message>
    <message>
        <source>Text</source>
        <translation> </translation>
    </message>
    <message>
        <source>Image</source>
        <translation> </translation>
    </message>
    <message>
        <source>Background color</source>
        <translation> </translation>
    </message>
    <message>
        <source>Color</source>
        <translation> </translation>
    </message>
    <message>
        <source>Font</source>
        <translation> </translation>
    </message>
    <message>
        <source>Position and Appearance</source>
        <translation> </translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation> </translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Offset</source>
        <translation> </translation>
    </message>
</context>
<context>
    <name>ZipFileManager</name>
    <message>
        <source>Can&apos;t create path</source>
        <translation type="unfinished">ไม่สามารถสร้าง path ได้</translation>
    </message>
    <message>
        <source>Can&apos;t create file</source>
        <translation type="unfinished">ไม่สามารถสร้างแฟ้มข้อมูลได้</translation>
    </message>
    <message>
        <source>Can&apos;t open file</source>
        <translation type="unfinished">ไม่สามารถเปิดแฟ้มข้อมูลได้</translation>
    </message>
</context>
</TS>
