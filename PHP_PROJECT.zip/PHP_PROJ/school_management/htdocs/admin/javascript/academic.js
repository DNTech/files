function check()
{
		dom=document.academicfrm
	var file=dom.userfile.value
		
		if(file!=["ce.pdf","cp.pdf"])
			{
				alert("Plese Chose correct file ");
				return false;
			}
}
// JavaScript Document