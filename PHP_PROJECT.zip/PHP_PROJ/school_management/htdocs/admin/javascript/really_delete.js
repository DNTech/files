function really_delete()
{
	dom = document.deleteall
	
	prompt("Are you sure to Delete All ?");
	if(ok)
	return true;
	else
	return false;
	
}