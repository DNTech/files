
<meta http-equiv="content-type" content="text/html; charset=ut
<title>JOBSCOPE</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />