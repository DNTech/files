<p>Copyright (c) 2010 jobscope.com. All rights reserved. <br />
			Design by PATEL RIDDHI</p>